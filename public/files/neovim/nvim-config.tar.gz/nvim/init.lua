-- Neovim 0.12 config. Entry point: set leader first (plugins read it when
-- they define mappings), then options, keymaps, autocmds, and finally lazy.nvim.
vim.g.mapleader = " "
vim.g.maplocalleader = " "

require("config.options")
require("config.keymaps")
require("config.autocmds")
require("config.lazy")

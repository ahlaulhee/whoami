local augroup = vim.api.nvim_create_augroup("config", { clear = true })

-- Briefly highlight yanked text
vim.api.nvim_create_autocmd("TextYankPost", {
  group = augroup,
  callback = function()
    vim.hl.on_yank()
  end,
})

-- 'autoread' only acts when timestamps are checked. Neovim does that when it
-- regains focus; this also checks when idle or switching buffers, so edits by
-- any agent show up while Neovim keeps the focus.
vim.api.nvim_create_autocmd({ "CursorHold", "BufEnter" }, {
  group = augroup,
  callback = function()
    if vim.fn.getcmdwintype() == "" then -- :checktime is not allowed in the cmdline window
      vim.cmd.checktime()
    end
  end,
})

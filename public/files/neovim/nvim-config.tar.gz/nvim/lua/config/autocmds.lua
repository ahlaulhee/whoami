local augroup = vim.api.nvim_create_augroup("config", { clear = true })

-- Briefly highlight yanked text
vim.api.nvim_create_autocmd("TextYankPost", {
  group = augroup,
  callback = function()
    vim.hl.on_yank()
  end,
})

-- 'autoread' only acts when timestamps are checked: Neovim does that on
-- FocusGained (tmux forwards focus events) and opencode.nvim on OpenCode's
-- edit events. This also checks when idle or switching buffers, so edits by
-- any agent (omp, ...) show up while Neovim keeps the focus.
vim.api.nvim_create_autocmd({ "CursorHold", "BufEnter" }, {
  group = augroup,
  callback = function()
    if vim.fn.getcmdwintype() == "" then -- :checktime is not allowed in the cmdline window
      vim.cmd.checktime()
    end
  end,
})

-- Prettier's default is 2 spaces; match it so typed code doesn't jump on save.
-- (Go and Python get their style from Neovim's ftplugins: tabs / 4 spaces.)
vim.api.nvim_create_autocmd("FileType", {
  group = augroup,
  pattern = {
    "javascript",
    "javascriptreact",
    "typescript",
    "typescriptreact",
    "json",
    "jsonc",
    "css",
    "html",
    "markdown",
  },
  callback = function()
    vim.bo.shiftwidth = 2
    vim.bo.tabstop = 2
  end,
})

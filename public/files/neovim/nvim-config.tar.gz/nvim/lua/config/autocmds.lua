local augroup = vim.api.nvim_create_augroup("config", { clear = true })

-- Briefly highlight yanked text
vim.api.nvim_create_autocmd("TextYankPost", {
  group = augroup,
  callback = function()
    vim.hl.on_yank()
  end,
})

-- Prettier's default is 2 spaces; match it so typed code doesn't jump on save.
-- (Go and Python get their style from Neovim's ftplugins: tabs / 4 spaces.)
vim.api.nvim_create_autocmd("FileType", {
  group = augroup,
  pattern = {
    "javascript",
    "javascriptreact",
    "typescript",
    "typescriptreact",
    "json",
    "jsonc",
    "css",
    "html",
    "markdown",
  },
  callback = function()
    vim.bo.shiftwidth = 2
    vim.bo.tabstop = 2
  end,
})

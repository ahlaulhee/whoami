local map = vim.keymap.set

map("i", "jj", "<Esc>", { desc = "Exit insert mode" })
map("t", "<Esc><Esc>", "<C-\\><C-n>", { desc = "Exit terminal mode" })
map({ "n", "x" }, "<C-s>", "<cmd>write<CR><Esc>", { desc = "Save file" })
map("n", "<Esc>", "<cmd>nohlsearch<CR>")
map("n", "x", '"_x', { desc = "Delete char (no yank)" })

-- Keep the cursor centred while scrolling and searching
map("n", "<C-d>", "<C-d>zz", { desc = "Scroll down (centred)" })
map("n", "<C-u>", "<C-u>zz", { desc = "Scroll up (centred)" })
map("n", "n", "nzzzv", { desc = "Next match (centred)" })
map("n", "N", "Nzzzv", { desc = "Previous match (centred)" })

-- Stay in visual mode after indenting; paste over a selection without yanking it
map("x", "<", "<gv", { desc = "Indent left" })
map("x", ">", ">gv", { desc = "Indent right" })
map("x", "p", "P", { desc = "Paste (keep register)" })

-- Buffers and splits
map("n", "<Tab>", "<cmd>bnext<CR>", { desc = "Next buffer" })
map("n", "<S-Tab>", "<cmd>bprevious<CR>", { desc = "Previous buffer" })
map("n", "<leader>x", "<cmd>bdelete<CR>", { desc = "Close buffer" })
map("n", "<leader>v", "<C-w>v", { desc = "Split vertically" })
map("n", "<leader>h", "<C-w>s", { desc = "Split horizontally" })

map("n", "<leader>q", vim.diagnostic.setloclist, { desc = "Diagnostics to loclist" })
map("n", "<leader>ns", "<cmd>setlocal spell! spell?<CR>", { desc = "Toggle spellcheck" })

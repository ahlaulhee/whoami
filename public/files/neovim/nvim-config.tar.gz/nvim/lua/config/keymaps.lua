-- Editor keymaps carried over from github.com/ahlaulhee/neovim. Plugin and LSP
-- keymaps live next to their plugin specs; the full table is in the notes.
local map = vim.keymap.set

-- Insert / terminal escapes
map("i", "jj", "<Esc>", { desc = "Exit insert mode" })
map("t", "<Esc><Esc>", "<C-\\><C-n>", { desc = "Exit terminal mode" })

-- Save (normal/visual only: insert-mode <C-s> stays the 0.11+ default LSP signature help)
map({ "n", "x" }, "<C-s>", "<cmd>write<CR><Esc>", { desc = "Save file" })

-- Clear search highlight
map("n", "<Esc>", "<cmd>nohlsearch<CR>")

-- Delete a character without overwriting the unnamed register
map("n", "x", '"_x', { desc = "Delete char (no yank)" })

-- Keep the cursor centred while scrolling and searching
map("n", "<C-d>", "<C-d>zz", { desc = "Scroll down (centred)" })
map("n", "<C-u>", "<C-u>zz", { desc = "Scroll up (centred)" })
map("n", "n", "nzzzv", { desc = "Next match (centred)" })
map("n", "N", "Nzzzv", { desc = "Previous match (centred)" })

-- Stay in visual mode after indenting
map("x", "<", "<gv", { desc = "Indent left" })
map("x", ">", ">gv", { desc = "Indent right" })

-- Paste over a selection without yanking it (built-in v_P keeps the register)
map("x", "p", "P", { desc = "Paste (keep register)" })

-- Buffers
map("n", "<Tab>", "<cmd>bnext<CR>", { desc = "Next buffer" })
map("n", "<S-Tab>", "<cmd>bprevious<CR>", { desc = "Previous buffer" })
map("n", "<leader>x", "<cmd>bdelete<CR>", { desc = "Close buffer" })

-- Splits (window movement is <C-h/j/k/l> via vim-tmux-navigator)
map("n", "<leader>v", "<C-w>v", { desc = "Split vertically" })
map("n", "<leader>h", "<C-w>s", { desc = "Split horizontally" })

-- Diagnostics: ]d/[d (next/prev) and <C-w>d (float) are Neovim defaults.
map("n", "<leader>q", vim.diagnostic.setloclist, { desc = "Diagnostics to loclist" })

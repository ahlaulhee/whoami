local o = vim.opt

-- UI
o.number = true
o.relativenumber = true
o.cursorline = true
o.signcolumn = "yes" -- always reserve the column so diagnostics/git signs don't shift text
o.showmode = false -- mini.statusline shows the mode
o.scrolloff = 10
o.splitright = true
o.splitbelow = true
o.list = true
o.listchars = { tab = "» ", trail = "·", nbsp = "␣" }
o.winborder = "rounded" -- default border for floats (hover, signature help, diagnostics)
o.inccommand = "split" -- live preview of :s in a split
o.confirm = true -- ask instead of failing on :q with unsaved changes

-- Editing
o.expandtab = true
o.shiftwidth = 4
o.tabstop = 4
o.breakindent = true
o.undofile = true
o.ignorecase = true
o.smartcase = true
o.mouse = "a"

-- Reload files changed on disk (by an agent in another tmux pane) when the
-- buffer has no unsaved edits. Already Neovim's default; explicit because
-- the checktime autocmd in config/autocmds.lua relies on it.
o.autoread = true

-- Timing: CursorHold and swap writes after 250 ms idle; multi-key mappings
-- (jj, <Esc><Esc>) wait 300 ms for the next key.
o.updatetime = 250
o.timeoutlen = 300

-- System clipboard through wl-clipboard (wl-copy/wl-paste are auto-detected
-- on Wayland). Scheduled because clipboard provider detection costs startup time.
vim.schedule(function()
  o.clipboard = "unnamedplus"
end)

-- Diagnostics: sort by severity and show a float after ]d/[d jumps
-- (`jump.float` is deprecated in 0.12; on_jump is its replacement).
vim.diagnostic.config({
  severity_sort = true,
  float = { source = "if_many" },
  virtual_text = { source = "if_many", spacing = 2 },
  jump = {
    on_jump = function(_, bufnr)
      vim.diagnostic.open_float({ bufnr = bufnr, scope = "cursor", focus = false })
    end,
  },
})

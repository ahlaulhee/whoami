-- Notes in ~/notes (a private git repo): inbox.md for quick captures and
-- TODOs, daily/, reference/, projects/, templates/ and attachments/.
local vault = vim.fn.expand("~/notes")

-- The inbox with the cursor on its last open task, ready for `o`. Finished
-- tasks sit below "## Done". Also what tmux's `prefix n` popup runs.
local function open_inbox()
  vim.cmd.edit(vault .. "/inbox.md")
  local done = vim.fn.search("^## Done$", "nw")
  local last = done > 0 and done - 1 or vim.fn.line("$")
  vim.api.nvim_win_set_cursor(0, { math.max(vim.fn.prevnonblank(last), 1), 0 })
end

-- `:Obsidian new_from_template` takes the title and the template together or
-- asks for both; this asks for the title alone.
local function new_project()
  vim.ui.input({ prompt = "Project: " }, function(title)
    if title and title ~= "" then
      vim.cmd.Obsidian({ args = { "new_from_template", title, "project" } })
    end
  end)
end

return {
  "obsidian-nvim/obsidian.nvim",
  version = "*",
  ft = "markdown",
  cmd = "Obsidian",
  keys = {
    { "<leader>ni", "<cmd>NotesInbox<CR>", desc = "Inbox" },
    { "<leader>nd", "<cmd>Obsidian today<CR>", desc = "Today's daily note" },
    { "<leader>nD", "<cmd>Obsidian dailies<CR>", desc = "Daily notes" },
    { "<leader>nn", "<cmd>Obsidian new<CR>", desc = "New reference note" },
    { "<leader>np", new_project, desc = "New project note" },
    { "<leader>nf", "<cmd>Obsidian quick_switch<CR>", desc = "Find note" },
    { "<leader>ng", "<cmd>Obsidian search<CR>", desc = "Grep notes" },
    { "<leader>nt", "<cmd>Obsidian tags<CR>", desc = "Notes by tag" },
  },
  init = function()
    vim.api.nvim_create_user_command("NotesInbox", open_inbox, { desc = "Open the notes inbox" })

    local group = vim.api.nvim_create_augroup("notes", { clear = true })

    -- obsidian.nvim's rendering (checkbox icons, hidden link syntax) needs
    -- 'conceallevel'. Defined before the plugin loads, so it runs before the
    -- plugin's own BufEnter check and no other file gets the option.
    vim.api.nvim_create_autocmd("BufEnter", {
      group = group,
      pattern = vault .. "/*.md",
      callback = function()
        vim.wo[0][0].conceallevel = 2
      end,
    })

    vim.api.nvim_create_autocmd("User", {
      group = group,
      pattern = "ObsidianNoteEnter",
      callback = function()
        local function map(lhs, rhs, desc, expr)
          vim.keymap.set("n", lhs, rhs, { buffer = true, desc = desc, expr = expr })
        end
        map("<leader>nb", "<cmd>Obsidian backlinks<CR>", "Backlinks")
        map("<leader>nT", "<cmd>Obsidian template<CR>", "Insert template")

        -- The plugin's own defaults, set again here because the keymaps
        -- cheatsheet (~/.local/bin/keymaps) only lists what this config sets.
        local actions = require("obsidian.actions")
        map("<CR>", actions.smart_action, "Follow link / toggle checkbox", true)
        map("]o", function()
          actions.nav_link("next", true)
        end, "Next link")
        map("[o", function()
          actions.nav_link("prev", true)
        end, "Previous link")
      end,
    })
  end,
  opts = function()
    local p = require("paradise.palette")
    return {
      legacy_commands = false,
      workspaces = { { name = "notes", path = vault } },
      picker = { name = "mini.pick" },

      -- New notes, and the ones made by following a link to a note that
      -- doesn't exist, go to reference/ as <slug of the title>.md.
      notes_subdir = "reference",
      new_notes_location = "notes_subdir",
      note_id_func = require("obsidian.builtin").title_id,
      note = { template = "note.md" },

      templates = {
        folder = "templates",
        customizations = {
          project = { notes_subdir = "projects" },
        },
      },
      daily_notes = {
        folder = "daily",
        template = "daily.md",
        default_tags = { "daily" },
      },

      frontmatter = {
        -- inbox.md stays a plain list.
        enabled = function(path)
          return tostring(path) ~= "inbox.md"
        end,
      },
      checkbox = { order = { " ", "x" } },

      ui = {
        hl_groups = {
          ObsidianTodo = { bold = true, fg = p.yellow },
          ObsidianDone = { bold = true, fg = p.green },
          ObsidianRightArrow = { bold = true, fg = p.blue },
          ObsidianTilde = { bold = true, fg = p.muted },
          ObsidianImportant = { bold = true, fg = p.red },
          ObsidianBullet = { bold = true, fg = p.blue },
          ObsidianRefText = { underline = true, fg = p.magenta },
          ObsidianExtLinkIcon = { fg = p.magenta },
          ObsidianTag = { italic = true, fg = p.cyan },
          ObsidianBlockID = { italic = true, fg = p.cyan },
          ObsidianHighlightText = { fg = p.bg, bg = p.yellow },
        },
      },
    }
  end,
}

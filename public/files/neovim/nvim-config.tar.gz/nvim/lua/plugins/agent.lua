-- opencode.nvim: https://github.com/nickjvandyke/opencode.nvim
-- Sends editor context (@this, @buffer, @diagnostics, ...) to OpenCode v2.
-- OpenCode itself runs in a tmux pane (prefix o in tmux.conf). Every v2
-- client shares one background service that registers its URL in
-- ~/.local/state/opencode/service.json; the plugin reads that file, so no
-- --port is needed. It also reloads buffers OpenCode edits (via :checktime)
-- and shows OpenCode's edit permission requests as diffs (da accept, dr reject).
-- snacks.nvim is optional (fancier ask/select); without it, ask() uses
-- vim.ui.input and select() uses vim.ui.select (= mini.pick, see plugins/mini.lua).
local function oc(fn, ...)
  local args = { ... }
  return function()
    return require("opencode")[fn](unpack(args))
  end
end

local nx = { "n", "x" }

return {
  "nickjvandyke/opencode.nvim",
  -- main branch targets OpenCode v2 (release tags support v1); pinned by lazy-lock.json.
  keys = {
    { "<leader>aa", oc("ask", "@this: "), mode = nx, desc = "Ask about @this (cursor/selection)" },
    { "<leader>ab", oc("ask", "@buffer: "), desc = "Ask about @buffer" },
    { "<leader>ad", oc("ask", "@diagnostics: "), mode = nx, desc = "Ask about @diagnostics" },
    { "<leader>as", oc("select"), mode = nx, desc = "Select prompt/command" },
    -- Operator: <leader>ao{motion} (or a visual selection) appends the range to
    -- OpenCode's prompt without asking; dot-repeatable.
    { "<leader>ao", oc("operator", "@this"), mode = nx, expr = true, desc = "Send range (motion)" },
    {
      "<leader>al",
      function()
        return require("opencode").operator("@this") .. "_"
      end,
      expr = true,
      desc = "Send line",
    },
  },
  init = function()
    ---@type opencode.Opts
    vim.g.opencode_opts = {
      server = {
        -- Called when no OpenCode server is found: open the TUI in a tmux
        -- split next to Neovim (focus stays here), the same as tmux prefix o.
        -- Outside tmux, fall back to the plugin's default terminal split.
        start = function()
          if vim.env.TMUX then
            vim.system({ "tmux", "split-window", "-h", "-d", "-c", vim.fn.getcwd(), "opencode" })
          else
            vim.cmd("vsplit term://opencode | wincmd p")
          end
        end,
      },
    }
  end,
}

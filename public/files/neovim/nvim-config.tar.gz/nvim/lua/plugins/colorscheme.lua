return {
  {
    "ahlaulhee/paradise.nvim",
    dev = true, -- ~/dev/paradise.nvim when it exists, GitHub otherwise
    lazy = false,
    priority = 1000,
    config = function()
      vim.cmd.colorscheme("paradise")
    end,
  },
  -- Fallback, not loaded at startup: `:colorscheme vague`
  { "vague-theme/vague.nvim", lazy = true },
}

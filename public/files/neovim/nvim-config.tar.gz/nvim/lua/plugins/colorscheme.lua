-- vague.nvim: https://github.com/vague-theme/vague.nvim
return {
  "vague-theme/vague.nvim",
  lazy = false,
  priority = 1000, -- load before every other UI plugin
  config = function()
    require("vague").setup({})
    vim.cmd.colorscheme("vague")
  end,
}

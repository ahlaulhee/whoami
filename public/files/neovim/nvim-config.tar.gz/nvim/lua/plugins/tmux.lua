-- vim-tmux-navigator: https://github.com/christoomey/vim-tmux-navigator
-- <C-h/j/k/l> move across Neovim splits and, at the edge, into tmux panes.
-- The tmux half is the snippet in ~/.config/tmux/tmux.conf.
return {
  "christoomey/vim-tmux-navigator",
  cmd = {
    "TmuxNavigateLeft",
    "TmuxNavigateDown",
    "TmuxNavigateUp",
    "TmuxNavigateRight",
    "TmuxNavigatePrevious",
    "TmuxNavigatorProcessList",
  },
  keys = {
    { "<C-h>", "<cmd><C-U>TmuxNavigateLeft<CR>", desc = "Window/pane left" },
    { "<C-j>", "<cmd><C-U>TmuxNavigateDown<CR>", desc = "Window/pane down" },
    { "<C-k>", "<cmd><C-U>TmuxNavigateUp<CR>", desc = "Window/pane up" },
    { "<C-l>", "<cmd><C-U>TmuxNavigateRight<CR>", desc = "Window/pane right" },
    { "<C-\\>", "<cmd><C-U>TmuxNavigatePrevious<CR>", desc = "Previous window/pane" },
  },
}

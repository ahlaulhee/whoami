-- mini.nvim: https://github.com/nvim-mini/mini.nvim
-- One plugin, several independent modules. Loaded at startup because the
-- statusline, starter screen and icon mock must exist before the first buffer.
return {
  "nvim-mini/mini.nvim",
  version = false, -- main branch; pinned by lazy-lock.json anyway
  lazy = false,
  priority = 900, -- after the colorscheme, before neo-tree asks for icons
  config = function()
    -- Text editing
    require("mini.ai").setup() -- more a/i textobjects: f(unction call), a(rgument), q(uote), ...
    require("mini.pairs").setup() -- auto-close brackets and quotes
    require("mini.surround").setup() -- sa/sd/sr/sf/sh: add/delete/replace/find/highlight surrounding

    -- UI
    require("mini.icons").setup()
    MiniIcons.mock_nvim_web_devicons() -- neo-tree asks nvim-web-devicons for icons
    require("mini.statusline").setup() -- shows gitsigns branch/diff and LSP diagnostics

    -- Picker (mini.extra adds diagnostics, oldfiles, LSP, keymaps, ... pickers)
    require("mini.pick").setup()
    require("mini.extra").setup()
    vim.ui.select = MiniPick.ui_select -- code actions, :Roslyn target, ... use the picker

    local starter = require("mini.starter")
    starter.setup({
      items = {
        starter.sections.pick(),
        starter.sections.recent_files(5, false, false),
        starter.sections.builtin_actions(),
      },
    })

    local pick, extra = MiniPick.builtin, MiniExtra.pickers
    local function map(lhs, rhs, desc)
      vim.keymap.set("n", lhs, rhs, { desc = desc })
    end
    map("<leader>sf", pick.files, "Search files")
    map("<leader>sg", pick.grep_live, "Search by grep (live)")
    map("<leader>sw", function()
      pick.grep({ pattern = vim.fn.expand("<cword>") })
    end, "Search word under cursor")
    map("<leader><leader>", pick.buffers, "Search buffers")
    map("<leader>sh", pick.help, "Search help")
    map("<leader>sd", extra.diagnostic, "Search diagnostics")
    map("<leader>sr", pick.resume, "Search resume")
    map("<leader>s.", extra.oldfiles, "Search recent files")
    map("<leader>sk", extra.keymaps, "Search keymaps")

    -- Key hints: pressing a trigger prefix waits for the next key (no
    -- 'timeoutlen') and shows what can follow after window.delay.
    local clue = require("mini.clue")
    clue.setup({
      triggers = {
        { mode = { "n", "x" }, keys = "<Leader>" },
        { mode = "n", keys = "[" },
        { mode = "n", keys = "]" },
        { mode = "i", keys = "<C-x>" },
        { mode = { "n", "x" }, keys = "g" },
        { mode = { "n", "x" }, keys = "'" },
        { mode = { "n", "x" }, keys = "`" },
        { mode = { "n", "x" }, keys = '"' },
        { mode = { "i", "c" }, keys = "<C-r>" },
        { mode = "n", keys = "<C-w>" },
        { mode = { "n", "x" }, keys = "z" },
      },
      clues = {
        { mode = "n", keys = "<Leader>s", desc = "+Search" },
        { mode = "n", keys = "<Leader>g", desc = "+Git" },
        { mode = { "n", "x" }, keys = "<Leader>a", desc = "+Agent (opencode)" },
        { mode = { "n", "x" }, keys = "<Leader>d", desc = "+Diff review" },
        clue.gen_clues.square_brackets(),
        clue.gen_clues.builtin_completion(),
        clue.gen_clues.g(),
        clue.gen_clues.marks(),
        clue.gen_clues.registers(),
        clue.gen_clues.windows(),
        clue.gen_clues.z(),
      },
      window = { delay = 300 }, -- default is 1000 ms
    })
  end,
}

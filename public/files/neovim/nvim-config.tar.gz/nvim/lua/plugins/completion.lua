-- blink.cmp: https://cmp.saghen.dev
-- Not lazy-loaded: blink defers its own work, and its plugin/ file registers
-- completion capabilities via vim.lsp.config("*") before any server starts.
return {
  "saghen/blink.cmp",
  version = "1.*", -- release tags ship a prebuilt Rust fuzzy matcher
  dependencies = { "rafamadriz/friendly-snippets" },
  opts = {
    keymap = { preset = "default" }, -- <C-y> accept, <C-n>/<C-p> select, <C-space> open, <C-e> hide
    appearance = { nerd_font_variant = "mono" },
    completion = {
      documentation = { auto_show = true, auto_show_delay_ms = 300 },
    },
    signature = { enabled = true },
    -- "default" = Neovim's built-in vim.snippet engine; friendly-snippets is
    -- picked up automatically by the snippets source.
    snippets = { preset = "default" },
    sources = {
      default = { "lsp", "path", "snippets", "buffer" },
      -- lazydev adds require()/module completions only in Lua buffers.
      per_filetype = {
        lua = { inherit_defaults = true, "lazydev" },
      },
      providers = {
        lazydev = { name = "LazyDev", module = "lazydev.integrations.blink", score_offset = 100 },
      },
    },
    fuzzy = { implementation = "prefer_rust_with_warning" },
  },
}

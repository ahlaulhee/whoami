-- conform.nvim: https://github.com/stevearc/conform.nvim
-- Formats on save; falls back to the LSP formatter when no CLI tool is set.
local prettier = { "prettierd" }

return {
  "stevearc/conform.nvim",
  event = "BufWritePre",
  cmd = "ConformInfo",
  keys = {
    {
      "<leader>f",
      function()
        require("conform").format({ async = true, lsp_format = "fallback" })
      end,
      mode = { "n", "x" },
      desc = "Format buffer/selection",
    },
  },
  opts = {
    formatters_by_ft = {
      cs = { "csharpier" },
      javascript = prettier,
      javascriptreact = prettier,
      typescript = prettier,
      typescriptreact = prettier,
      json = prettier,
      jsonc = prettier,
      css = prettier,
      html = prettier,
      yaml = prettier,
      markdown = prettier,
      go = { "goimports", "gofumpt" },
      lua = { "stylua" },
      python = { "ruff_organize_imports", "ruff_format" },
    },
    format_on_save = function(bufnr)
      -- csharpier starts a .NET process; give it more time than the others.
      local timeout = vim.bo[bufnr].filetype == "cs" and 3000 or 1000
      return { timeout_ms = timeout, lsp_format = "fallback" }
    end,
  },
}

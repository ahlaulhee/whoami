return {
  "nvim-neo-tree/neo-tree.nvim",
  branch = "v3.x",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "MunifTanjim/nui.nvim",
  },
  lazy = false, -- neo-tree defers its own loading; this lets it open on `nvim <dir>`
  keys = {
    { "<leader>e", "<cmd>Neotree toggle reveal<CR>", desc = "Explorer (reveal file)" },
  },
  opts = {
    filesystem = {
      follow_current_file = { enabled = true },
      use_libuv_file_watcher = true,
    },
  },
}

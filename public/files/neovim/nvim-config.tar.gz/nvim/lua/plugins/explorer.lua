-- neo-tree.nvim: https://github.com/nvim-neo-tree/neo-tree.nvim
-- Icons come from mini.icons' nvim-web-devicons mock (see plugins/mini.lua).
return {
  "nvim-neo-tree/neo-tree.nvim",
  branch = "v3.x",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "MunifTanjim/nui.nvim",
  },
  lazy = false, -- neo-tree defers its own loading; this lets it hijack `nvim <dir>`
  keys = {
    { "<leader>e", "<cmd>Neotree toggle reveal<CR>", desc = "Explorer (reveal file)" },
  },
  opts = {
    filesystem = {
      follow_current_file = { enabled = true },
      use_libuv_file_watcher = true,
    },
  },
}

-- Servers enabled through vim.lsp.enable (nvim-lspconfig names).
-- C# (roslyn) is started by roslyn.nvim instead.
local servers = {
  "vtsls", "html", "cssls", "jsonls", "tailwindcss",
  "gopls", "lua_ls", "basedpyright", "ruff",
}

-- Everything mason installs (mason package names).
local tools = {
  -- language servers
  "roslyn", "vtsls", "html-lsp", "css-lsp", "json-lsp", "tailwindcss-language-server",
  "gopls", "lua-language-server", "basedpyright", "ruff",
  -- formatters (conform.nvim)
  "csharpier", "prettierd", "goimports", "gofumpt", "stylua",
  -- linters (nvim-lint)
  "eslint_d", "golangci-lint",
}

return {
  {
    "mason-org/mason.nvim",
    lazy = false, -- puts mason's bin dir on PATH before any server starts
    opts = {
      registries = {
        "github:mason-org/mason-registry",
        "github:Crashdummyy/mason-registry", -- provides `roslyn`
      },
    },
    config = function(_, opts)
      require("mason").setup(opts)

      local registry = require("mason-registry")
      local function install_missing()
        local missing = vim.tbl_filter(function(name)
          return not registry.is_installed(name)
        end, tools)
        if #missing > 0 then
          vim.cmd.MasonInstall({ "--quiet", unpack(missing) })
        end
      end
      vim.api.nvim_create_user_command("MasonInstallAll", install_missing, {
        desc = "Install every tool listed in plugins/lsp.lua",
      })
      vim.api.nvim_create_autocmd("VimEnter", { once = true, callback = install_missing })
    end,
  },

  {
    "neovim/nvim-lspconfig",
    lazy = false,
    dependencies = { "mason-org/mason.nvim" },
    config = function()
      -- ruff and basedpyright both serve Python; basedpyright owns hover and imports.
      vim.lsp.config("basedpyright", {
        settings = { basedpyright = { disableOrganizeImports = true } },
      })
      vim.lsp.enable(servers)

      vim.api.nvim_create_autocmd("LspAttach", {
        group = vim.api.nvim_create_augroup("lsp_attach", { clear = true }),
        callback = function(args)
          local client = assert(vim.lsp.get_client_by_id(args.data.client_id))
          if client.name == "ruff" then
            client.server_capabilities.hoverProvider = false
          end

          local function map(lhs, rhs, desc)
            vim.keymap.set("n", lhs, rhs, { buffer = args.buf, desc = desc })
          end
          local pick_lsp = function(scope)
            return function()
              require("mini.extra").pickers.lsp({ scope = scope })
            end
          end
          map("gd", pick_lsp("definition"), "Goto definition")
          map("gD", vim.lsp.buf.declaration, "Goto declaration")
          map("gR", pick_lsp("references"), "References (picker)")
          map("<leader>ss", pick_lsp("document_symbol"), "Document symbols")
          map("<leader>sS", pick_lsp("workspace_symbol"), "Workspace symbols")
        end,
      })
    end,
  },

  {
    "seblyng/roslyn.nvim",
    ft = { "cs", "razor" },
    dependencies = { "mason-org/mason.nvim" },
    opts = {},
  },

  {
    "folke/lazydev.nvim",
    ft = "lua",
    opts = {
      library = {
        { path = "${3rd}/luv/library", words = { "vim%.uv" } },
      },
    },
  },
}

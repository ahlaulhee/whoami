-- Native LSP (vim.lsp.config / vim.lsp.enable) with server defaults from
-- nvim-lspconfig's lsp/*.lua files and binaries from mason.nvim.

-- Servers enabled through vim.lsp.enable (nvim-lspconfig names).
-- C# (roslyn) is started by roslyn.nvim instead.
local servers = {
  -- TypeScript/JavaScript/React + web files
  "vtsls",
  "html",
  "cssls",
  "jsonls",
  "tailwindcss", -- only attaches in projects with a Tailwind config/dependency
  -- Go, Lua, Python
  "gopls",
  "lua_ls",
  "basedpyright", -- types, hover, completion
  "ruff", -- lint diagnostics + quick fixes
}

-- Everything mason installs (mason package names).
local tools = {
  -- language servers
  "roslyn",
  "vtsls",
  "html-lsp",
  "css-lsp",
  "json-lsp",
  "tailwindcss-language-server",
  "gopls",
  "lua-language-server",
  "basedpyright",
  "ruff",
  -- formatters (conform.nvim)
  "csharpier",
  "prettierd",
  "goimports",
  "gofumpt",
  "stylua",
  -- linters (nvim-lint)
  "eslint_d",
  "golangci-lint",
}

return {
  -- mason.nvim: https://github.com/mason-org/mason.nvim
  {
    "mason-org/mason.nvim",
    lazy = false, -- puts mason's bin dir on PATH before any server starts
    opts = {
      registries = {
        "github:mason-org/mason-registry",
        "github:Crashdummyy/mason-registry", -- provides `roslyn` (same build as the VS Code extension)
      },
    },
    config = function(_, opts)
      require("mason").setup(opts)

      -- Install whatever in `tools` is missing. :MasonInstall opens the Mason
      -- window (or blocks until done when headless:
      -- `nvim --headless +MasonInstallAll +qa` bootstraps a new machine).
      -- --quiet: when called from Lua, streamed installer stderr (e.g. `go:
      -- downloading ...`) would be raised as an error and abort the wait.
      local registry = require("mason-registry")
      local function install_missing()
        local missing = vim.tbl_filter(function(name)
          return not registry.is_installed(name)
        end, tools)
        if #missing > 0 then
          vim.cmd.MasonInstall({ "--quiet", unpack(missing) })
        end
      end
      vim.api.nvim_create_user_command("MasonInstallAll", install_missing, {
        desc = "Install every tool listed in plugins/lsp.lua",
      })
      -- Interactive sessions check on startup; headless `-c` commands run
      -- before VimEnter, so scripts are never interrupted by this.
      vim.api.nvim_create_autocmd("VimEnter", { once = true, callback = install_missing })
    end,
  },

  -- nvim-lspconfig: https://github.com/neovim/nvim-lspconfig
  -- Only used for its lsp/<server>.lua defaults (cmd, filetypes, root markers).
  {
    "neovim/nvim-lspconfig",
    lazy = false,
    dependencies = { "mason-org/mason.nvim" },
    config = function()
      -- Two Python servers: basedpyright for types/hover/completion, ruff for
      -- lint, quick fixes and import sorting (so basedpyright's is disabled).
      vim.lsp.config("basedpyright", {
        settings = { basedpyright = { disableOrganizeImports = true } },
      })
      vim.lsp.enable(servers)

      vim.api.nvim_create_autocmd("LspAttach", {
        group = vim.api.nvim_create_augroup("lsp_attach", { clear = true }),
        callback = function(args)
          local client = assert(vim.lsp.get_client_by_id(args.data.client_id))
          -- Ruff's editor docs: disable its hover in favour of (based)pyright's.
          if client.name == "ruff" then
            client.server_capabilities.hoverProvider = false
          end

          -- grn/gra/grr/gri/grt/gO/K and insert <C-s> are Neovim defaults.
          local function map(lhs, rhs, desc)
            vim.keymap.set("n", lhs, rhs, { buffer = args.buf, desc = desc })
          end
          local pick_lsp = function(scope)
            return function()
              require("mini.extra").pickers.lsp({ scope = scope })
            end
          end
          map("gd", pick_lsp("definition"), "Goto definition")
          map("gD", vim.lsp.buf.declaration, "Goto declaration")
          map("gR", pick_lsp("references"), "References (picker)")
          map("<leader>ss", pick_lsp("document_symbol"), "Document symbols")
          map("<leader>sS", pick_lsp("workspace_symbol_live"), "Workspace symbols (live query)")
        end,
      })
    end,
  },

  -- roslyn.nvim: https://github.com/seblyng/roslyn.nvim
  -- Finds the .sln/.csproj and starts the Roslyn server (mason `roslyn`).
  {
    "seblyng/roslyn.nvim",
    ft = { "cs", "razor" },
    dependencies = { "mason-org/mason.nvim" },
    opts = {},
  },

  -- lazydev.nvim: https://github.com/folke/lazydev.nvim
  -- Makes lua_ls aware of the Neovim runtime and installed plugins.
  {
    "folke/lazydev.nvim",
    ft = "lua",
    opts = {
      library = {
        { path = "${3rd}/luv/library", words = { "vim%.uv" } },
      },
    },
  },
}

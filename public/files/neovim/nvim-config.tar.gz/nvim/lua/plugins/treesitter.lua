-- nvim-treesitter (main branch rewrite): https://github.com/nvim-treesitter/nvim-treesitter/tree/main
-- It only installs parsers + queries; highlighting is Neovim's own
-- vim.treesitter.start(), switched on per filetype below. Needs tree-sitter-cli
-- and a C compiler on PATH. Does not support lazy-loading.
local parsers = {
  "c_sharp",
  "typescript",
  "tsx",
  "javascript",
  "go",
  "lua",
  "python",
  "html",
  "css",
  "json",
  "yaml",
  "bash",
  "vim",
  "vimdoc",
  "query",
  "markdown",
  "markdown_inline", -- markdown injects markdown_inline for emphasis/links
}

return {
  {
    "nvim-treesitter/nvim-treesitter",
    branch = "main",
    lazy = false,
    build = ":TSUpdate",
    config = function()
      -- Install missing parsers once the UI is up (async; a no-op when all are
      -- installed). Headless `-c` commands run before VimEnter, so scripted
      -- installs (`install(...):wait()`) never race this one.
      vim.api.nvim_create_autocmd("VimEnter", {
        once = true,
        callback = function()
          require("nvim-treesitter").install(parsers)
        end,
      })

      -- Parser names are not filetype names (c_sharp -> cs, tsx -> typescriptreact, ...).
      local filetypes = {}
      for _, lang in ipairs(parsers) do
        vim.list_extend(filetypes, vim.treesitter.language.get_filetypes(lang))
      end

      vim.api.nvim_create_autocmd("FileType", {
        group = vim.api.nvim_create_augroup("treesitter", { clear = true }),
        pattern = filetypes,
        callback = function(args)
          -- pcall: the parser may still be compiling on the very first start.
          if pcall(vim.treesitter.start, args.buf) then
            vim.bo[args.buf].indentexpr = "v:lua.require'nvim-treesitter'.indentexpr()"
          end
        end,
      })
    end,
  },

  -- nvim-ts-autotag: https://github.com/windwp/nvim-ts-autotag
  -- Auto-close and auto-rename HTML/JSX/TSX tags.
  {
    "windwp/nvim-ts-autotag",
    event = { "BufReadPre", "BufNewFile" },
    opts = {
      opts = {
        enable_close = true,
        enable_rename = true,
        enable_close_on_slash = false,
      },
    },
  },
}

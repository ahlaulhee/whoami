local linters_by_ft = {
  javascript = { "eslint_d" },
  javascriptreact = { "eslint_d" },
  typescript = { "eslint_d" },
  typescriptreact = { "eslint_d" },
  go = { "golangcilint" },
}

-- eslint_d reports an error in projects without an ESLint config; only run it where one exists.
local eslint_configs = {
  "eslint.config.js", "eslint.config.mjs", "eslint.config.cjs",
  "eslint.config.ts", "eslint.config.mts", "eslint.config.cts",
}

return {
  "mfussenegger/nvim-lint",
  ft = vim.tbl_keys(linters_by_ft),
  config = function()
    local lint = require("lint")
    lint.linters_by_ft = linters_by_ft

    vim.api.nvim_create_autocmd({ "BufReadPost", "BufWritePost", "InsertLeave" }, {
      group = vim.api.nvim_create_augroup("lint", { clear = true }),
      callback = function(args)
        local names = linters_by_ft[vim.bo[args.buf].filetype] or {}
        if not vim.fs.root(args.buf, eslint_configs) then
          names = vim.tbl_filter(function(name)
            return name ~= "eslint_d"
          end, names)
        end
        lint.try_lint(names)
      end,
    })
  end,
}

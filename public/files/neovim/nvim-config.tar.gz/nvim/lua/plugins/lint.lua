-- nvim-lint: https://github.com/mfussenegger/nvim-lint
-- Python linting is ruff's language server, so only JS/TS and Go are here.
local linters_by_ft = {
  javascript = { "eslint_d" },
  javascriptreact = { "eslint_d" },
  typescript = { "eslint_d" },
  typescriptreact = { "eslint_d" },
  go = { "golangcilint" },
}

-- eslint_d reports a "no config found" error in projects without an ESLint
-- (flat) config; only run it where one exists.
local eslint_configs = {
  "eslint.config.js",
  "eslint.config.mjs",
  "eslint.config.cjs",
  "eslint.config.ts",
  "eslint.config.mts",
  "eslint.config.cts",
}

return {
  "mfussenegger/nvim-lint",
  -- Load on FileType (not BufReadPost): lazy.nvim replays the event for the
  -- new autocmds, and on BufReadPost 'filetype' is not set yet.
  ft = vim.tbl_keys(linters_by_ft),
  config = function()
    local lint = require("lint")
    lint.linters_by_ft = linters_by_ft

    vim.api.nvim_create_autocmd({ "BufReadPost", "BufWritePost", "InsertLeave" }, {
      group = vim.api.nvim_create_augroup("lint", { clear = true }),
      callback = function(args)
        local names = linters_by_ft[vim.bo[args.buf].filetype] or {}
        if not vim.fs.root(args.buf, eslint_configs) then
          names = vim.tbl_filter(function(name)
            return name ~= "eslint_d"
          end, names)
        end
        lint.try_lint(names)
      end,
    })
  end,
}

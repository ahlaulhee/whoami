-- codediff.nvim: https://github.com/esmuellert/codediff.nvim
-- VSCode-style diff tab for reviewing what an agent (opencode, omp, ...)
-- changes in the working tree: the explorer refreshes itself as files change
-- (native watcher, 500 ms polling fallback), and files/hunks can be staged
-- or discarded in place. Works on git state only, so it is agent-agnostic.
-- The diff library (libvscode_diff_<version>.so) and the codediff-watcher
-- binary are downloaded into the plugin directory on first use;
-- `:CodeDiff install` does the library explicitly.
-- In the view: ]c/[c hunks, ]f/[f files, - stage/unstage file, S/U stage/unstage
-- all, X discard file, t inline/side-by-side, gf open file, q close, g? help.
return {
  "esmuellert/codediff.nvim",
  cmd = "CodeDiff",
  keys = {
    { "<leader>dd", "<cmd>CodeDiff<CR>", desc = "Review working tree changes" },
    { "<leader>ds", "<cmd>CodeDiff --staged<CR>", desc = "Review staged changes" },
    { "<leader>df", "<cmd>CodeDiff file HEAD<CR>", desc = "Diff file vs HEAD" },
    { "<leader>dh", "<cmd>CodeDiff history %<CR>", desc = "File history" },
    { "<leader>dh", ":CodeDiff history<CR>", mode = "x", desc = "Selected lines history" },
    { "<leader>dH", "<cmd>CodeDiff history<CR>", desc = "Repo history" },
  },
  opts = {
    keymaps = {
      view = {
        -- Defaults are <leader>hs/hu/hr, which would shadow <leader>h (split)
        -- inside the diff tab; reuse gitsigns' <leader>g hunk keys instead.
        stage_hunk = "<leader>gs",
        unstage_hunk = "<leader>gu",
        discard_hunk = "<leader>gr",
      },
    },
  },
}

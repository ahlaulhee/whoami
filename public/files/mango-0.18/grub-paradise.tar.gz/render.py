#!/usr/bin/env python3
"""Regenerate the theme's PNGs. Run it after changing a colour, a size or an icon.

GRUB builds the menu frame and the selection bar from nine images each
(corners, edges and centre) and stretches the edges and the centre to fit.
Here every piece is a flat colour, so the frame and the bar come out square.
"""
from pathlib import Path

import gi

gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf  # noqa: E402

HERE = Path(__file__).resolve().parent

# Paradise, as 0xRRGGBBAA.
BG = 0x151515FF
BORDER = 0x424242FF
FOCUS = 0x8DA3B9FF

BORDER_PX = 2  # menu frame thickness
BAR_PAD = 4  # selection bar left of the icon tile and right of the text
ICON_PX = 24  # must match icon_width and icon_height in theme.txt


def flat(name: str, width: int, height: int, colour: int) -> None:
    pixbuf = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, True, 8, width, height)
    pixbuf.fill(colour)
    pixbuf.savev(str(HERE / name), "png", [], [])


for side in ("nw", "n", "ne", "w", "e", "sw", "s", "se"):
    flat(f"menu_{side}.png", BORDER_PX, BORDER_PX, BORDER)
flat("menu_c.png", 1, 1, BG)

flat("select_w.png", BAR_PAD, 1, FOCUS)
flat("select_c.png", 1, 1, FOCUS)
flat("select_e.png", BAR_PAD, 1, FOCUS)

# GRUB looks an entry's icon up by its class: icons/<class>.png.
for svg in sorted((HERE / "icons").glob("*.svg")):
    icon = GdkPixbuf.Pixbuf.new_from_file_at_size(str(svg), ICON_PX, ICON_PX)
    icon.savev(str(svg.with_suffix(".png")), "png", [], [])

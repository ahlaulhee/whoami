#!/bin/sh
# Install the Paradise GRUB theme: copy it to /boot, switch GRUB to the
# graphical terminal at 2560x1440 and regenerate grub.cfg. Safe to run again.
#
#   sudo ~/dotfiles/grub/install.sh
#
# To undo, restore /etc/default/grub.pre-paradise over /etc/default/grub and
# run: grub2-mkconfig -o /boot/grub2/grub.cfg
set -eu

src=$(cd "$(dirname "$0")" && pwd)
theme=/boot/grub2/themes/paradise
defaults=/etc/default/grub
efi=/boot/efi/EFI/fedora/grubx64.efi

[ "$(id -u)" -eq 0 ] || { echo "run as root: sudo $0" >&2; exit 1; }

# With Secure Boot GRUB can't load modules from disk, so the theme only works
# if the signed image already contains png, gfxmenu and gfxterm. Each string
# below comes from one of them.
for needle in 'png: chunk size error' 'selected_item_pixmap_style' 'grub_gfxterm_background'; do
    grep -aqF "$needle" "$efi" || {
        echo "$efi lacks a module the theme needs (no '$needle'); nothing changed" >&2
        exit 1
    }
done

install -d "$theme/icons"
install -m 644 "$src/theme.txt" "$src"/*.png "$theme/"
install -m 644 "$src"/icons/*.png "$theme/icons/"

[ -e "$defaults.pre-paradise" ] || cp -p "$defaults" "$defaults.pre-paradise"

set_default() {
    if grep -q "^$1=" "$defaults"; then
        sed -i "s|^$1=.*|$1=\"$2\"|" "$defaults"
    else
        printf '%s="%s"\n' "$1" "$2" >> "$defaults"
    fi
}
set_default GRUB_TERMINAL_OUTPUT gfxterm
set_default GRUB_GFXMODE 2560x1440,auto
set_default GRUB_THEME "$theme/theme.txt"

grub2-mkconfig -o /boot/grub2/grub.cfg
